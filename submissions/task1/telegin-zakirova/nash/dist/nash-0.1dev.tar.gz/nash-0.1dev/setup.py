from distutils.core import setup

setup(
    name = 'nash',
    version = '0.1dev',
    packages = ['nash_task',],
    license = 'MIT',
    long_descriptions = open('README.txt').read(),
)
